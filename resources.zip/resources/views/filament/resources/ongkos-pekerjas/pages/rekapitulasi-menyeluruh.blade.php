<x-filament-panels::page>
    {{-- Page content --}}
</x-filament-panels::page>
