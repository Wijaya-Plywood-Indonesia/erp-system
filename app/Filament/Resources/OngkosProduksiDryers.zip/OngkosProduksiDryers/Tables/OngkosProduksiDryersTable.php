<?php

namespace App\Filament\Resources\OngkosProduksiDryers\Tables;

use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class OngkosProduksiDryersTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id_produksi_dryer')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('total_m3')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('ttl_pekerja')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('jumlah_mesin')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('tarif_per_pekerja')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('tarif_per_mesin')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('ongkos_pekerja')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('ongkos_mesin')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('total_ongkos')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('ongkos_per_m3')
                    ->numeric()
                    ->sortable(),
                IconColumn::make('is_final')
                    ->boolean(),
                TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                //
            ])
            ->recordActions([
                EditAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}
