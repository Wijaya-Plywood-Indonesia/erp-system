<?php

namespace App\Filament\Resources\OngkosProduksiDryers\Schemas;

use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class OngkosProduksiDryerForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Select::make('id_produksi_dryer')
                    ->label('Sesi Produksi')
                    ->relationship(
                        'produksi',
                        'id',
                        fn(Builder $q) => $q->orderByDesc('tanggal_produksi')
                    )
                    ->getOptionLabelFromRecordUsing(fn($r) => $r->label)
                    ->searchable()->required()
                    ->disabled(fn($record) => $record?->is_final),
                TextInput::make('total_m3')
                    ->required()
                    ->numeric()
                    ->default(0.0),
                TextInput::make('ttl_pekerja')
                    ->required()
                    ->numeric()
                    ->default(0),
                TextInput::make('jumlah_mesin')
                    ->required()
                    ->numeric()
                    ->default(0),
                TextInput::make('tarif_per_pekerja')
                    ->required()
                    ->numeric()
                    ->default(115000.0),
                TextInput::make('tarif_per_mesin')
                    ->required()
                    ->numeric()
                    ->default(335000.0),
                TextInput::make('ongkos_pekerja')
                    ->required()
                    ->numeric()
                    ->default(0.0),
                TextInput::make('ongkos_mesin')
                    ->required()
                    ->numeric()
                    ->default(0.0),
                TextInput::make('total_ongkos')
                    ->required()
                    ->numeric()
                    ->default(0.0),
                TextInput::make('ongkos_per_m3')
                    ->numeric(),
                Toggle::make('is_final')
                    ->required(),
            ]);
    }
}
