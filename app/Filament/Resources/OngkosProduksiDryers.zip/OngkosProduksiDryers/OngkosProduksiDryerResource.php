<?php

namespace App\Filament\Resources\OngkosProduksiDryers;

use App\Filament\Resources\OngkosProduksiDryers\Pages\CreateOngkosProduksiDryer;
use App\Filament\Resources\OngkosProduksiDryers\Pages\EditOngkosProduksiDryer;
use App\Filament\Resources\OngkosProduksiDryers\Pages\ListOngkosProduksiDryers;
use App\Filament\Resources\OngkosProduksiDryers\Schemas\OngkosProduksiDryerForm;
use App\Filament\Resources\OngkosProduksiDryers\Tables\OngkosProduksiDryersTable;
use App\Models\OngkosProduksiDryer;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;

class OngkosProduksiDryerResource extends Resource
{
    protected static ?string $model = OngkosProduksiDryer::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedRectangleStack;

    public static function form(Schema $schema): Schema
    {
        return OngkosProduksiDryerForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return OngkosProduksiDryersTable::configure($table);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListOngkosProduksiDryers::route('/'),
            'create' => CreateOngkosProduksiDryer::route('/create'),
            'edit' => EditOngkosProduksiDryer::route('/{record}/edit'),
        ];
    }
}
