<?php

namespace App\Filament\Resources\DetailNotaBarangKeluars\Pages;

use App\Filament\Resources\DetailNotaBarangKeluars\DetailNotaBarangKeluarResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailNotaBarangKeluar extends CreateRecord
{
    protected static string $resource = DetailNotaBarangKeluarResource::class;
}
