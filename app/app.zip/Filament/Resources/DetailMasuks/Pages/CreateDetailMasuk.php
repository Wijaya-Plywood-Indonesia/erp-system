<?php

namespace App\Filament\Resources\DetailMasuks\Pages;

use App\Filament\Resources\DetailMasuks\DetailMasukResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailMasuk extends CreateRecord
{
    protected static string $resource = DetailMasukResource::class;
}
