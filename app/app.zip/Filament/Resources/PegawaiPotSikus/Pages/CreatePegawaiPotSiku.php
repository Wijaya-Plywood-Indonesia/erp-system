<?php

namespace App\Filament\Resources\PegawaiPotSikus\Pages;

use App\Filament\Resources\PegawaiPotSikus\PegawaiPotSikuResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePegawaiPotSiku extends CreateRecord
{
    protected static string $resource = PegawaiPotSikuResource::class;
}
