<?php

namespace App\Filament\Resources\HasilPotAfJoints\Pages;

use App\Filament\Resources\HasilPotAfJoints\HasilPotAfJointResource;
use Filament\Resources\Pages\CreateRecord;

class CreateHasilPotAfJoint extends CreateRecord
{
    protected static string $resource = HasilPotAfJointResource::class;
}
