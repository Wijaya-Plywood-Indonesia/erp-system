<?php

namespace App\Filament\Resources\LainLains\Pages;

use App\Filament\Resources\LainLains\LainLainResource;
use Filament\Resources\Pages\CreateRecord;

class CreateLainLain extends CreateRecord
{
    protected static string $resource = LainLainResource::class;
}
