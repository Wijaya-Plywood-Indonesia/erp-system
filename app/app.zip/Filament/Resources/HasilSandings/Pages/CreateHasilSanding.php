<?php

namespace App\Filament\Resources\HasilSandings\Pages;

use App\Filament\Resources\HasilSandings\HasilSandingResource;
use Filament\Resources\Pages\CreateRecord;

class CreateHasilSanding extends CreateRecord
{
    protected static string $resource = HasilSandingResource::class;
}
