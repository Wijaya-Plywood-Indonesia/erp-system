<?php

namespace App\Filament\Resources\DetailKomposisis\Pages;

use App\Filament\Resources\DetailKomposisis\DetailKomposisiResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailKomposisi extends CreateRecord
{
    protected static string $resource = DetailKomposisiResource::class;
}
