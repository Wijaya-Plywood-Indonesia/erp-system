<?php

namespace App\Filament\Resources\BahanProduksis\Pages;

use App\Filament\Resources\BahanProduksis\BahanProduksiResource;
use Filament\Resources\Pages\CreateRecord;

class CreateBahanProduksi extends CreateRecord
{
    protected static string $resource = BahanProduksiResource::class;
}
