<?php

namespace App\Filament\Resources\PegawaiPotAfJoints\Pages;

use App\Filament\Resources\PegawaiPotAfJoints\PegawaiPotAfJointResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePegawaiPotAfJoint extends CreateRecord
{
    protected static string $resource = PegawaiPotAfJointResource::class;
}
