<?php

namespace App\Filament\Resources\PegawaiNyusups\Pages;

use App\Filament\Resources\PegawaiNyusups\PegawaiNyusupResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePegawaiNyusup extends CreateRecord
{
    protected static string $resource = PegawaiNyusupResource::class;
}
