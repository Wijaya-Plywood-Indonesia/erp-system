<?php

namespace App\Filament\Resources\HasilGrajiTripleks\Pages;

use App\Filament\Resources\HasilGrajiTripleks\HasilGrajiTriplekResource;
use Filament\Resources\Pages\CreateRecord;

class CreateHasilGrajiTriplek extends CreateRecord
{
    protected static string $resource = HasilGrajiTriplekResource::class;
}
