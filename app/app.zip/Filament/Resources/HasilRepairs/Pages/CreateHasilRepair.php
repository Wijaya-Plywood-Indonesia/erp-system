<?php

namespace App\Filament\Resources\HasilRepairs\Pages;

use App\Filament\Resources\HasilRepairs\HasilRepairResource;
use Filament\Resources\Pages\CreateRecord;

class CreateHasilRepair extends CreateRecord
{
    protected static string $resource = HasilRepairResource::class;
}
