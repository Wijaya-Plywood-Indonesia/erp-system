<?php

namespace App\Filament\Resources\HasilJoints\Pages;

use App\Filament\Resources\HasilJoints\HasilJointResource;
use Filament\Resources\Pages\CreateRecord;

class CreateHasilJoint extends CreateRecord
{
    protected static string $resource = HasilJointResource::class;
}
