<?php

namespace App\Filament\Resources\BahanPenolongHps\Pages;

use App\Filament\Resources\BahanPenolongHps\BahanPenolongHpResource;
use Filament\Resources\Pages\CreateRecord;

class CreateBahanPenolongHp extends CreateRecord
{
    protected static string $resource = BahanPenolongHpResource::class;
}
