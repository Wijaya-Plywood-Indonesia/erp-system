<?php

namespace App\Filament\Resources\PegawaiGrajiTripleks\Pages;

use App\Filament\Resources\PegawaiGrajiTripleks\PegawaiGrajiTriplekResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePegawaiGrajiTriplek extends CreateRecord
{
    protected static string $resource = PegawaiGrajiTriplekResource::class;
}
