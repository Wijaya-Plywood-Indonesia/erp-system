<?php

namespace App\Filament\Resources\JenisBarangs\Pages;

use App\Filament\Resources\JenisBarangs\JenisBarangResource;
use Filament\Resources\Pages\CreateRecord;

class CreateJenisBarang extends CreateRecord
{
    protected static string $resource = JenisBarangResource::class;
}
