<?php

namespace App\Filament\Resources\DetailLainLains\Pages;

use App\Filament\Resources\DetailLainLains\DetailLainLainResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailLainLain extends CreateRecord
{
    protected static string $resource = DetailLainLainResource::class;
}
