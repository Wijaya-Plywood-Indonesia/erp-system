<?php

namespace App\Filament\Resources\PlatformBahanHps\Pages;

use App\Filament\Resources\PlatformBahanHps\PlatformBahanHpResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePlatformBahanHp extends CreateRecord
{
    protected static string $resource = PlatformBahanHpResource::class;
}
