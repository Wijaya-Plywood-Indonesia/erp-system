<?php

namespace App\Filament\Resources\DokumenKayus\Pages;

use App\Filament\Resources\DokumenKayus\DokumenKayuResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDokumenKayu extends CreateRecord
{
    protected static string $resource = DokumenKayuResource::class;
}
