<?php

namespace App\Filament\Resources\PegawaiPotJeleks\Pages;

use App\Filament\Resources\PegawaiPotJeleks\PegawaiPotJelekResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePegawaiPotJelek extends CreateRecord
{
    protected static string $resource = PegawaiPotJelekResource::class;
}
