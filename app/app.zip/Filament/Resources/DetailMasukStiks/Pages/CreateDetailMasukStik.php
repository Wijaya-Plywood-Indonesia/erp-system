<?php

namespace App\Filament\Resources\DetailMasukStiks\Pages;

use App\Filament\Resources\DetailMasukStiks\DetailMasukStikResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailMasukStik extends CreateRecord
{
    protected static string $resource = DetailMasukStikResource::class;
}
