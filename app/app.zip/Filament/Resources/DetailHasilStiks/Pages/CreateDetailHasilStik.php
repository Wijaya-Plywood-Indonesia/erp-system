<?php

namespace App\Filament\Resources\DetailHasilStiks\Pages;

use App\Filament\Resources\DetailHasilStiks\DetailHasilStikResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailHasilStik extends CreateRecord
{
    protected static string $resource = DetailHasilStikResource::class;
}
