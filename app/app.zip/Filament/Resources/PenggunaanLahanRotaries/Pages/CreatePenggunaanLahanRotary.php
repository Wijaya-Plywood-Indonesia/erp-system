<?php

namespace App\Filament\Resources\PenggunaanLahanRotaries\Pages;

use App\Filament\Resources\PenggunaanLahanRotaries\PenggunaanLahanRotaryResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePenggunaanLahanRotary extends CreateRecord
{
    protected static string $resource = PenggunaanLahanRotaryResource::class;
}
