<?php

namespace App\Filament\Resources\PegawaiRotaries\Pages;

use App\Filament\Resources\PegawaiRotaries\PegawaiRotaryResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePegawaiRotary extends CreateRecord
{
    protected static string $resource = PegawaiRotaryResource::class;
}
