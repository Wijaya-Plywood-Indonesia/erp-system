<?php

namespace App\Filament\Resources\PegawaiTurunKayus\Pages;

use App\Filament\Resources\PegawaiTurunKayus\PegawaiTurunKayuResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePegawaiTurunKayu extends CreateRecord
{
    protected static string $resource = PegawaiTurunKayuResource::class;
}
