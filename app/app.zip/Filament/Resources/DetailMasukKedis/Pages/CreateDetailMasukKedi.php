<?php

namespace App\Filament\Resources\DetailMasukKedis\Pages;

use App\Filament\Resources\DetailMasukKedis\DetailMasukKediResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailMasukKedi extends CreateRecord
{
    protected static string $resource = DetailMasukKediResource::class;
}
