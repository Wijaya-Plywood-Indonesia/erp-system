<?php

namespace App\Filament\Resources\PegawaiPilihPlywoods\Pages;

use App\Filament\Resources\PegawaiPilihPlywoods\PegawaiPilihPlywoodResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePegawaiPilihPlywood extends CreateRecord
{
    protected static string $resource = PegawaiPilihPlywoodResource::class;
}
