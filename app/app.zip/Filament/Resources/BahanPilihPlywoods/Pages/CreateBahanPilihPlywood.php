<?php

namespace App\Filament\Resources\BahanPilihPlywoods\Pages;

use App\Filament\Resources\BahanPilihPlywoods\BahanPilihPlywoodResource;
use Filament\Resources\Pages\CreateRecord;

class CreateBahanPilihPlywood extends CreateRecord
{
    protected static string $resource = BahanPilihPlywoodResource::class;
}
