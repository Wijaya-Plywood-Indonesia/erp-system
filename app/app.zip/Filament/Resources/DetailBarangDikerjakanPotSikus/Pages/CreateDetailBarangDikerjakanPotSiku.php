<?php

namespace App\Filament\Resources\DetailBarangDikerjakanPotSikus\Pages;

use App\Filament\Resources\DetailBarangDikerjakanPotSikus\DetailBarangDikerjakanPotSikuResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailBarangDikerjakanPotSiku extends CreateRecord
{
    protected static string $resource = DetailBarangDikerjakanPotSikuResource::class;
}
