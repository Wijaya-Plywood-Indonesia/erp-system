<?php

namespace App\Filament\Resources\DetailHasils\Pages;

use App\Filament\Resources\DetailHasils\DetailHasilResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailHasil extends CreateRecord
{
    protected static string $resource = DetailHasilResource::class;
}
