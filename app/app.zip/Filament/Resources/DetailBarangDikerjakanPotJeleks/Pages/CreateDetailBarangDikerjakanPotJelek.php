<?php

namespace App\Filament\Resources\DetailBarangDikerjakanPotJeleks\Pages;

use App\Filament\Resources\DetailBarangDikerjakanPotJeleks\DetailBarangDikerjakanPotJelekResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailBarangDikerjakanPotJelek extends CreateRecord
{
    protected static string $resource = DetailBarangDikerjakanPotJelekResource::class;
}
