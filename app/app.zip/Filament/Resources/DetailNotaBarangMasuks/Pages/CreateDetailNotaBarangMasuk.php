<?php

namespace App\Filament\Resources\DetailNotaBarangMasuks\Pages;

use App\Filament\Resources\DetailNotaBarangMasuks\DetailNotaBarangMasukResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailNotaBarangMasuk extends CreateRecord
{
    protected static string $resource = DetailNotaBarangMasukResource::class;
}
