<?php

namespace App\Filament\Resources\Komposisis\Pages;

use App\Filament\Resources\Komposisis\KomposisiResource;
use Filament\Resources\Pages\CreateRecord;

class CreateKomposisi extends CreateRecord
{
    protected static string $resource = KomposisiResource::class;
}
