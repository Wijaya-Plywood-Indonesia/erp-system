<?php

namespace App\Filament\Resources\DetailBarangDikerjakans\Pages;

use App\Filament\Resources\DetailBarangDikerjakans\DetailBarangDikerjakanResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailBarangDikerjakan extends CreateRecord
{
    protected static string $resource = DetailBarangDikerjakanResource::class;
}
