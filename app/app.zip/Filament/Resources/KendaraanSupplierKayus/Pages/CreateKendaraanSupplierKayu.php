<?php

namespace App\Filament\Resources\KendaraanSupplierKayus\Pages;

use App\Filament\Resources\KendaraanSupplierKayus\KendaraanSupplierKayuResource;
use Filament\Resources\Pages\CreateRecord;

class CreateKendaraanSupplierKayu extends CreateRecord
{
    protected static string $resource = KendaraanSupplierKayuResource::class;
}
