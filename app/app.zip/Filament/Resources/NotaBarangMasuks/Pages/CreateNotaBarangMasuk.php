<?php

namespace App\Filament\Resources\NotaBarangMasuks\Pages;

use App\Filament\Resources\NotaBarangMasuks\NotaBarangMasukResource;
use Filament\Resources\Pages\CreateRecord;

class CreateNotaBarangMasuk extends CreateRecord
{
    protected static string $resource = NotaBarangMasukResource::class;
}
