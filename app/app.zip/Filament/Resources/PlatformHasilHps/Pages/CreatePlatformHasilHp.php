<?php

namespace App\Filament\Resources\PlatformHasilHps\Pages;

use App\Filament\Resources\PlatformHasilHps\PlatformHasilHpResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePlatformHasilHp extends CreateRecord
{
    protected static string $resource = PlatformHasilHpResource::class;
}
