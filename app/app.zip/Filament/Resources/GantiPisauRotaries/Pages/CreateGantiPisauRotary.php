<?php

namespace App\Filament\Resources\GantiPisauRotaries\Pages;

use App\Filament\Resources\GantiPisauRotaries\GantiPisauRotaryResource;
use Filament\Resources\Pages\CreateRecord;

class CreateGantiPisauRotary extends CreateRecord
{
    protected static string $resource = GantiPisauRotaryResource::class;

}
