<?php

namespace App\Filament\Resources\PegawaiSandings\Pages;

use App\Filament\Resources\PegawaiSandings\PegawaiSandingResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePegawaiSanding extends CreateRecord
{
    protected static string $resource = PegawaiSandingResource::class;
}
