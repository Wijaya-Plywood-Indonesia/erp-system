<?php

namespace App\Filament\Resources\DetailDempuls\Pages;

use App\Filament\Resources\DetailDempuls\DetailDempulResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailDempul extends CreateRecord
{
    protected static string $resource = DetailDempulResource::class;
}
