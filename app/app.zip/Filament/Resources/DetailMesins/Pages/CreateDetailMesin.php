<?php

namespace App\Filament\Resources\DetailMesins\Pages;

use App\Filament\Resources\DetailMesins\DetailMesinResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailMesin extends CreateRecord
{
    protected static string $resource = DetailMesinResource::class;
}
