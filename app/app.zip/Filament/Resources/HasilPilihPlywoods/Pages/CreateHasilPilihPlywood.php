<?php

namespace App\Filament\Resources\HasilPilihPlywoods\Pages;

use App\Filament\Resources\HasilPilihPlywoods\HasilPilihPlywoodResource;
use Filament\Resources\Pages\CreateRecord;

class CreateHasilPilihPlywood extends CreateRecord
{
    protected static string $resource = HasilPilihPlywoodResource::class;
}
