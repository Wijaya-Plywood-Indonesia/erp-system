<?php

namespace App\Filament\Resources\PegawaiStiks\Pages;

use App\Filament\Resources\PegawaiStiks\PegawaiStikResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePegawaiStik extends CreateRecord
{
    protected static string $resource = PegawaiStikResource::class;
}
