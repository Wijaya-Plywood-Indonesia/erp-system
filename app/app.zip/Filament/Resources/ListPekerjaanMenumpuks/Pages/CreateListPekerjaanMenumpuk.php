<?php

namespace App\Filament\Resources\ListPekerjaanMenumpuks\Pages;

use App\Filament\Resources\ListPekerjaanMenumpuks\ListPekerjaanMenumpukResource;
use Filament\Resources\Pages\CreateRecord;

class CreateListPekerjaanMenumpuk extends CreateRecord
{
    protected static string $resource = ListPekerjaanMenumpukResource::class;
}
