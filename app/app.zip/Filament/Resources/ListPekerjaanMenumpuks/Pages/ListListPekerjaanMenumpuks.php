<?php

namespace App\Filament\Resources\ListPekerjaanMenumpuks\Pages;

use App\Filament\Resources\ListPekerjaanMenumpuks\ListPekerjaanMenumpukResource;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ListRecords;

class ListListPekerjaanMenumpuks extends ListRecords
{
    protected static string $resource = ListPekerjaanMenumpukResource::class;

    // protected function getHeaderActions(): array
    // {
    //     // return [
    //     //     CreateAction::make(),
    //     // ];
    // }
}
