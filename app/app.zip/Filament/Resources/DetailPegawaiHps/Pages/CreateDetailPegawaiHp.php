<?php

namespace App\Filament\Resources\DetailPegawaiHps\Pages;

use App\Filament\Resources\DetailPegawaiHps\DetailPegawaiHpResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailPegawaiHp extends CreateRecord
{
    protected static string $resource = DetailPegawaiHpResource::class;
}
