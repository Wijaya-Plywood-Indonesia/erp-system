<?php

namespace App\Filament\Resources\BahanDempuls\Pages;

use App\Filament\Resources\BahanDempuls\BahanDempulResource;
use Filament\Resources\Pages\CreateRecord;

class CreateBahanDempul extends CreateRecord
{
    protected static string $resource = BahanDempulResource::class;
}
