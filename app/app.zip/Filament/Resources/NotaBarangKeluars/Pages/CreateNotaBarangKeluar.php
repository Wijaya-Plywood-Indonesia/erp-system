<?php

namespace App\Filament\Resources\NotaBarangKeluars\Pages;

use App\Filament\Resources\NotaBarangKeluars\NotaBarangKeluarResource;
use Filament\Resources\Pages\CreateRecord;

class CreateNotaBarangKeluar extends CreateRecord
{
    protected static string $resource = NotaBarangKeluarResource::class;
}
