<?php

namespace App\Filament\Resources\PegawaiJoints\Pages;

use App\Filament\Resources\PegawaiJoints\PegawaiJointResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePegawaiJoint extends CreateRecord
{
    protected static string $resource = PegawaiJointResource::class;
}
