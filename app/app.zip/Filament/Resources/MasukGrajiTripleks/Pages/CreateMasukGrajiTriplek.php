<?php

namespace App\Filament\Resources\MasukGrajiTripleks\Pages;

use App\Filament\Resources\MasukGrajiTripleks\MasukGrajiTriplekResource;
use Filament\Resources\Pages\CreateRecord;

class CreateMasukGrajiTriplek extends CreateRecord
{
    protected static string $resource = MasukGrajiTriplekResource::class;
}
