<?php

namespace App\Filament\Resources\DetailPegawaiKedis\Pages;

use App\Filament\Resources\DetailPegawaiKedis\DetailPegawaiKediResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailPegawaiKedi extends CreateRecord
{
    protected static string $resource = DetailPegawaiKediResource::class;
}
