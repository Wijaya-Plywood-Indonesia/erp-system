<?php

namespace App\Filament\Resources\DetailBongkarKedis\Pages;

use App\Filament\Resources\DetailBongkarKedis\DetailBongkarKediResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDetailBongkarKedi extends CreateRecord
{
    protected static string $resource = DetailBongkarKediResource::class;
}
